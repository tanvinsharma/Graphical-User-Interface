using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using lab2.Models;

namespace lab2.Services{
    public class FileReader{
        public List<RecipeModel> Recipes { get; set; }

        public FileReader(){
            Recipes = new List<RecipeModel>();

            ReadFile();
        }

        private void ReadFile(){
            string FilePath = "recipes.json";

            StreamReader r = new StreamReader(FilePath);
            string json = r.ReadToEnd();
            r.Close();

            JObject allRecipes = JObject.Parse(json);

            foreach(JProperty recipeEntry in allRecipes.Properties()){   
                string name = recipeEntry.Name;
                List<string> description = new List<string>();
                List<string> ingredients = new List<string>();
                List<string> amountAndUnit = new List<string>();

                JObject recipeBody = JObject.Parse(recipeEntry.Value.ToString());

                foreach(JProperty recipeElement in recipeBody.Properties()){
                    if(recipeElement.Name != "recipe"){
                        ingredients.Add(recipeElement.Name.ToString());
                        amountAndUnit.Add(recipeElement.Value.ToString());
                    }
                    else{
                        var recipeDescription = (JArray)recipeElement.Value;
                        foreach(var line in recipeDescription){
                            description.Add(line.ToString());
                        }
                    }
                }
            
                RecipeModel recipe = new RecipeModel(name, description, ingredients, amountAndUnit);
                Recipes.Add(recipe);
            }
        }
    }
}


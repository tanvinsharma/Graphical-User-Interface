using System;
using System.Collections.Generic;
using lab2.Models;

namespace lab2.Services{
    public class RecipeService{
        FileWriter Writer;
        FileReader Reader;

        public RecipeService(){
            Writer = new FileWriter();
            Reader = new FileReader();
        }

        public void AddRecipe(RecipeModel recipe){
            List<RecipeModel> recipes = new List<RecipeModel>(Reader.Recipes);

            recipes.Add(recipe);

            Writer.write(recipes);
        }

        public void EditRecipe(RecipeModel recipe, string oldRecipeName){
            List<RecipeModel> filteredRecipes = Reader.Recipes.FindAll(r => r.recipeName != oldRecipeName);

            filteredRecipes.Add(recipe);

            Writer.write(filteredRecipes);
        }

        public void DeleteRecipe(string name){
            List<RecipeModel> recipes = new List<RecipeModel>(Reader.Recipes);

            List<RecipeModel> filteredRecipes = Reader.Recipes.FindAll(r => r.recipeName != name);

            Writer.write(filteredRecipes);
        }
    }
}
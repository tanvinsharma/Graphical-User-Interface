using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using System.Linq;
using lab2.Models;
using Newtonsoft.Json.Linq;

namespace lab2.Services{
  public class FileWriter{
    string FilePath;

    public FileWriter(){
      FilePath = "recipes.json";
    }

    public void write(List<RecipeModel> recipes){
      JObject allData = new JObject();

      foreach(RecipeModel recipe in recipes){
        JObject recipeObject = new JObject();

        JArray descriptionArray = new JArray();

                //store recipe description
        foreach(string line in recipe.description){
          descriptionArray.Add(line);
        }

                //store recipe description as property to object "recipe"
        recipeObject.Add(new JProperty("recipe", descriptionArray));

                //store ingredients
        for(int i = 0; i < recipe.ingredients.Count(); i++){
          recipeObject.Add(new JProperty(recipe.ingredients.ElementAt(i), recipe.amountAndUnit.ElementAt(i)));
        }
        allData.Add(new JProperty(recipe.recipeName, recipeObject));
      }
      System.IO.File.WriteAllText(FilePath, JsonConvert.SerializeObject(allData));
    }
  }
}
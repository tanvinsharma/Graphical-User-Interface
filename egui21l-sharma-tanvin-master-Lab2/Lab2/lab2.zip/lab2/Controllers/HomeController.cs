﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using lab2.Models;
using lab2.Services;

namespace lab2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;

            if(recipes.Last().recipeName == "toAdd" || recipes.Last().recipeName == "toShop")
            {
                recipeService.DeleteRecipe(recipes.Last().recipeName);
            }

            HomeViewModel model = new HomeViewModel(recipes);

            return View(model);
        }

        public IActionResult add()
        {
            FileReader fileReader = new FileReader();
            List<RecipeModel> recipes = fileReader.Recipes;
            HomeViewModel model = new HomeViewModel(recipes);

            return View(model);
        }

        public IActionResult edit(string recipeToEdit)
        {
            FileReader fileReader = new FileReader();
            List<RecipeModel> recipes = fileReader.Recipes;
            int index = 0;

            for (int i = 0; i < recipes.Count(); i++)
            {
                if(recipes.ElementAt(i).recipeName == recipeToEdit)
                {
                    index = i;
                }
            }
            RecipeModel recipeModel = new RecipeModel(recipes.ElementAt(index).recipeName, recipes.ElementAt(index).description, recipes.ElementAt(index).ingredients, recipes.ElementAt(index).amountAndUnit);
            EditViewModel model = new EditViewModel(recipeModel);

            return View(model);
        }

        public IActionResult shoppingList()
        {
            FileReader fileReader = new FileReader();
            List<RecipeModel> recipes = fileReader.Recipes;
            RecipeService recipeService = new RecipeService();
            HomeViewModel model = new HomeViewModel(recipes);

            if(recipes.Last().recipeName != "toShop")
            {
                List<string> descriptions = new List<string>();
                descriptions.Add(" ");

                List<string> ingredients = new List<string>();
                ingredients.Add(" ");
                List<string> amountAndUnit = new List<string>();
                amountAndUnit.Add(" ");

                RecipeModel recipeToShop = new RecipeModel("toShop", descriptions, ingredients, amountAndUnit);
                recipeService.AddRecipe(recipeToShop);
            }

            return View(model);
        }

        public IActionResult addRecipe(string recipename, string description)
        {
            if(string.IsNullOrEmpty(recipename) || string.IsNullOrEmpty(description))
            {
                return RedirectToAction("add");
            }

            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;

            List<string> descriptions = new List<string>();
            descriptions = description.Split("\r\n").ToList();

            List<string> ingredients = new List<string>();
            List<string> amountAndUnit = new List<string>();

            if(recipes.Last().recipeName != "toAdd")
            {
                ingredients.Add(" ");
                amountAndUnit.Add(" ");

                RecipeModel recipeModel = new RecipeModel(recipename, descriptions, ingredients, amountAndUnit);
                recipeService.AddRecipe(recipeModel);
            }
            else
            {
                ingredients = recipes.Last().ingredients;
                amountAndUnit = recipes.Last().amountAndUnit;
                recipeService.DeleteRecipe("toAdd");

                RecipeModel recipeModel = new RecipeModel(recipename, descriptions, ingredients, amountAndUnit);
                recipeService.AddRecipe(recipeModel);
            }

            return RedirectToAction("Index");
        }

        public IActionResult deleteRecipe(string recipeToDelete)
        {
            RecipeService recipeService = new RecipeService();

            recipeService.DeleteRecipe(recipeToDelete);
            
            return RedirectToAction("Index");
        }

        public IActionResult editRecipe(string oldRecipeName, string newRecipeName, string description)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;

            List<string> descriptions = new List<string>();
            descriptions = description.Split("\r\n").ToList();

            List<string> ingredients = new List<string>();
            List<string> amountAndUnit = new List<string>();

            for (int i = 0; i < recipes.Count(); i++)
            {
                if(recipes.ElementAt(i).recipeName == oldRecipeName)
                {
                    RecipeModel recipeModel = new RecipeModel(newRecipeName, descriptions, recipes.ElementAt(i).ingredients, recipes.ElementAt(i).amountAndUnit);
                    recipeService.EditRecipe(recipeModel, oldRecipeName);
                }
            }

            return RedirectToAction("Index");
        }
        
        public IActionResult deleteIngredient(string ingredientToDelete)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;

            for (int i = 0; i < recipes.Last().ingredients.Count(); i++)
            {
                if(recipes.Last().ingredients.ElementAt(i) == ingredientToDelete)
                {
                    recipes.Last().ingredients.RemoveAt(i);
                    recipes.Last().amountAndUnit.RemoveAt(i);                

                    RecipeModel recipeModel = new RecipeModel(recipes.Last().recipeName, recipes.Last().description, recipes.Last().ingredients, recipes.Last().amountAndUnit);
                    recipeService.EditRecipe(recipeModel, recipes.Last().recipeName);
                }
            }
            
            return RedirectToAction("add");
        }

        public IActionResult deleteIngredientAndEditRecipe(string ingredientToDelete, string recipeToEdit)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;
            int index = 0;

            for (int i = 0; i < recipes.Count(); i++)
            {
                if(recipes.ElementAt(i).recipeName == recipeToEdit)
                {
                    index = i;
                    for(int j = 0; j < recipes.ElementAt(i).ingredients.Count(); j++)
                    {
                        if(recipes.ElementAt(i).ingredients.ElementAt(j) == ingredientToDelete)
                        {
                            recipes.ElementAt(i).ingredients.RemoveAt(j);
                            recipes.ElementAt(i).amountAndUnit.RemoveAt(j);
                        }
                    }
                }
            }
            RecipeModel recipeModel = new RecipeModel(recipes.ElementAt(index).recipeName, recipes.ElementAt(index).description, recipes.ElementAt(index).ingredients, recipes.ElementAt(index).amountAndUnit);
            recipeService.EditRecipe(recipeModel, recipes.ElementAt(index).recipeName);

            return RedirectToAction("edit", new {recipeToEdit});
        }

        public IActionResult addIngredient(string ingredient, string quantity, string unit)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;

            float quantityFloat = 0;
            bool isFloat = float.TryParse(quantity, out quantityFloat);

            if(isFloat != true)
            {
                return RedirectToAction("add");
            }

            string measure = quantity + " " + unit;

            if(recipes.Last().recipeName != "toAdd")
            {
                string inProgress = "toAdd";

                List<string> descriptions = new List<string>();
                descriptions.Add(" ");

                List<string> ingredients = new List<string>();
                ingredients.Add(ingredient);

                List<string> amountAndUnit = new List<string>();
                amountAndUnit.Add(measure);

                RecipeModel recipeModel = new RecipeModel(inProgress, descriptions, ingredients, amountAndUnit);
                recipeService.AddRecipe(recipeModel);
            }
            else
            {
                recipes.Last().ingredients.Add(ingredient);
                recipes.Last().amountAndUnit.Add(measure);
                RecipeModel recipeModel = new RecipeModel(recipes.Last().recipeName, recipes.Last().description, recipes.Last().ingredients, recipes.Last().amountAndUnit);
                recipeService.EditRecipe(recipeModel, recipes.Last().recipeName);
            }

            return RedirectToAction("add");
        }

        public IActionResult addIngredientAndEditRecipe(string ingredient, string quantity, string unit, string recipeToEdit)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;
            int index = 0;

            float quantityFloat = 0;
            bool isFloat = float.TryParse(quantity, out quantityFloat);

            if(isFloat != true)
            {
                return RedirectToAction("edit", new {recipeToEdit});
            }

            string measure = quantity + " " + unit;

            for (int i = 0; i < recipes.Count(); i++)
            {
                if(recipes.ElementAt(i).recipeName == recipeToEdit)
                {
                    index = i;
                    recipes.ElementAt(i).ingredients.Add(ingredient);
                    recipes.ElementAt(i).amountAndUnit.Add(measure);

                    RecipeModel recipeModel = new RecipeModel(recipes.ElementAt(i).recipeName, recipes.ElementAt(i).description, recipes.ElementAt(i).ingredients, recipes.ElementAt(i).amountAndUnit);
                    recipeService.EditRecipe(recipeModel, recipes.ElementAt(i).recipeName);
                }
            }

            return RedirectToAction("edit", new {recipeToEdit});
        }

        public IActionResult addRecipeToShoppingList(string recipeToShoppingList)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;
            int index = 0;

            for (int i = 0; i < recipes.Count(); i++)
            {
                if(recipes.ElementAt(i).recipeName == recipeToShoppingList)
                {
                    index = i;
                }
            }

            for (int i = 0; i < recipes.ElementAt(index).ingredients.Count(); i++)
            {
                bool ingredientFound = false;
                for (int j = 0; j < recipes.Last().ingredients.Count(); j++)
                {
                    if (recipes.ElementAt(index).ingredients.ElementAt(i) == recipes.Last().ingredients.ElementAt(j))
                    {
                        ingredientFound = true;

                        if(recipes.ElementAt(index).amountAndUnit.ElementAt(i) == recipes.Last().amountAndUnit.ElementAt(j))
                        {
                            string[] measure = new string[]{};
                            string[] measureLast = new string[]{};
                            measure = recipes.ElementAt(index).amountAndUnit.ElementAt(i).Split(' ');
                            measureLast = recipes.Last().amountAndUnit.ElementAt(j).Split(' ');

                            float measureLastFloat = float.Parse(measureLast[0], CultureInfo.InvariantCulture.NumberFormat);
                            float measureFloat = float.Parse(measure[0], CultureInfo.InvariantCulture.NumberFormat);
                            measureLastFloat = measureLastFloat + measureFloat;
                            string measureLastString = measureLastFloat.ToString();
                            string newAmountAndUnit = measureLastString + " " + measure[1];

                            recipes.Last().ingredients.RemoveAt(j);
                            recipes.Last().amountAndUnit.RemoveAt(j);
                            
                            recipes.Last().ingredients.Add(recipes.ElementAt(index).ingredients.ElementAt(i));
                            recipes.Last().amountAndUnit.Add(newAmountAndUnit);
                        }
                    }
                }
                if(ingredientFound == false)
                {
                    recipes.Last().ingredients.Add(recipes.ElementAt(index).ingredients.ElementAt(i));
                    recipes.Last().amountAndUnit.Add(recipes.ElementAt(index).amountAndUnit.ElementAt(i));
                }
            }
            RecipeModel recipeModel = new RecipeModel(recipes.Last().recipeName, recipes.Last().description, recipes.Last().ingredients, recipes.Last().amountAndUnit);
            recipeService.EditRecipe(recipeModel, recipes.Last().recipeName);

            return RedirectToAction("shoppingList");
        }

        public IActionResult removeRecipeFromShoppingList(string recipeToShoppingList)
        {
            FileReader fileReader = new FileReader();
            RecipeService recipeService = new RecipeService();
            List<RecipeModel> recipes = fileReader.Recipes;

            for (int i = 0; i < recipes.Count(); i++)
            {
                if(recipes.ElementAt(i).recipeName == recipeToShoppingList)
                {
                    for (int j = 0; j < recipes.ElementAt(i).ingredients.Count(); j++)
                    {
                        for (int z = 0; z < recipes.Last().ingredients.Count(); z++)
                        {
                            if(recipes.Last().ingredients.ElementAt(z) == recipes.ElementAt(i).ingredients.ElementAt(j) && recipes.Last().amountAndUnit.ElementAt(z) == recipes.ElementAt(i).amountAndUnit.ElementAt(j))
                            {
                                recipes.Last().ingredients.RemoveAt(z);
                                recipes.Last().amountAndUnit.RemoveAt(z);
                            }
                        }
                    }
                    RecipeModel recipeModel = new RecipeModel(recipes.Last().recipeName, recipes.Last().description, recipes.Last().ingredients, recipes.Last().amountAndUnit);
                    recipeService.EditRecipe(recipeModel, recipes.Last().recipeName);
                }
            }
            return RedirectToAction("shoppingList");
        }
    }
}


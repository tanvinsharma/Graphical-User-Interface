using System;
using System.Collections.Generic;

namespace lab2.Models{
    public class EditViewModel{
        public RecipeModel recipeToEdit { get; set; }

        public EditViewModel(RecipeModel recipe){
            this.recipeToEdit = recipe;
        }   
    }
}
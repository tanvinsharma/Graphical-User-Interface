using System;
using System.Collections.Generic;

namespace lab2.Models{
    public class HomeViewModel{
        public List<RecipeModel> recipeList { get; set; }

        public HomeViewModel(List<RecipeModel> recipes){
            this.recipeList = recipes;
        }   
    }
}
using System;
using System.Collections.Generic;

namespace lab2.Models{
    public class RecipeModel{
        public string recipeName { get; }
        public List<string> description { get; }
        public List<string> ingredients { get; }
        public List<string> amountAndUnit { get; }

        public RecipeModel(string name, List<string> description, List<string> ingredients, List<string> amountAndUnit){
            this.recipeName = name;
            this.description = description;
            this.ingredients = ingredients;
            this.amountAndUnit = amountAndUnit;
        }
    }

    public class Measure{
        public string Amount { get; set; }
        public string Unit { get ;set; }

        Measure(string measure){
            this.Amount = measure;
            this.Unit = measure;
        }
    }
}